import Navbar from './components/Navbar/Navbar'
import Hero from './components/Hero/Hero'
import Proyectos from './components/Proyectos/Proyectos'
import Footer from './components/Footer/Footer'

function App() {
  return (
    <div className="page">
      <Navbar />

      <main>
        <Hero />
        </main>

      <Footer />
    </div>
  )
}

export default App