import './Navbar.css'
import Proyecto from '../Proyectos/Proyectos'

function Navbar() {
  return (
    <header className="navbar">
      <div className="navbar-container">

        <a href="#" className="navbar-logo">
          <img
            src="/logo2026.png"
            alt="Grupo Inmobiliario Leones"
          />
        </a>

        <nav className="navbar-menu">

          <a href="#" className="active">
            Inicio
          </a>

          <div className="nav-proyectos">
            <button className="nav-link-button">
              Proyectos
            </button>

            <div className="proyectos-flotante">
              <Proyecto />
            </div>
          </div>

          <a href="#lotes">Lotes</a>
          <a href="#comunicados">Comunicados</a>
          <a href="#nosotros">Nosotros</a>
          <a href="#promociones">Promociones</a>
          <a href="#contacto">Contacto</a>

        </nav>

        <button className="client-button">
          Área cliente
        </button>

        <button className="menu-button" aria-label="Abrir menú">
          ☰
        </button>

      </div>
    </header>
  )
}

export default Navbar